// content.js
(() => {
  // bsc : or = then one/more 8-digit ids, optionally comma-separated (case-insensitive)
  const TAG_RE = /bsc["':=\s]+(\d{8}(?:,\s*\d{8})*)/gi;

  // Scan helpers
  const scanHTML = (html) => {
    if (!html) return [];
    const matches = [...html.matchAll(TAG_RE)];
    return matches.flatMap(m => m[1].split(',').map(s => s.trim()))
                  .filter(s => /^\d{8}$/.test(s));
  };

  const scanDocumentOnce = () => {
    const html = document.documentElement?.innerHTML ?? '';
    const fromHTML = scanHTML(html);

    // Also scan inline <script> contents (NYT and similar embed JSON/text here)
    const fromScripts = Array.from(document.scripts || [])
      .map(sc => sc.textContent || '')
      .flatMap(scanHTML);

    // Merge + dedupe
    return Array.from(new Set([...fromHTML, ...fromScripts]));
  };

  const send = (tags) => chrome.runtime.sendMessage({ bscTagsFound: tags });

  // Immediate scan
  let found = scanDocumentOnce();
  if (found.length) {
    send(found);
    return; // done
  }

  // Otherwise, watch for late content for up to 6 seconds
  let done = false;
  const debounce = (fn, ms = 200) => {
    let t;
    return () => { clearTimeout(t); t = setTimeout(fn, ms); };
  };

  const tryScan = debounce(() => {
    if (done) return;
    const tags = scanDocumentOnce();
    if (tags.length) {
      done = true;
      observer.disconnect();
      send(tags);
    }
  }, 250);

  const observer = new MutationObserver(() => {
    tryScan();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true
  });

  // Hard timeout: after 6s, stop and report "none" so the UI updates
  setTimeout(() => {
    if (!done) {
      done = true;
      observer.disconnect();
      send([]); // empty array: "no tags found"
    }
  }, 6000);
})();
