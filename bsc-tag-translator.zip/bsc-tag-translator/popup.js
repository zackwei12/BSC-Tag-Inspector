// popup.js — frame-agnostic, no runtime messaging needed

const translateButton = document.getElementById('translateBtn');
const resultsDiv = document.getElementById('results');

const safeHTML = (s) => s.replace(/[&<>]/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]));

// This function will be injected into EVERY frame and must be self-contained
async function scanForBscTags() {
  try {
    const TAG_RE = /bsc["':=\s]+(\d{8}(?:,\s*\d{8})*)/gi;

    const scanHTML = (html) => {
      if (!html) return [];
      const matches = [...html.matchAll(TAG_RE)];
      return matches
        .flatMap(m => m[1].split(',').map(s => s.trim()))
        .filter(s => /^\d{8}$/.test(s));
    };

    const scanOnce = () => {
      const html = document.documentElement?.innerHTML ?? '';
      const fromHTML = scanHTML(html);

      // Inline <script> content often holds the tag lists
      const fromScripts = Array.from(document.scripts || [])
        .map(sc => sc.textContent || '')
        .flatMap(scanHTML);

      return Array.from(new Set([...fromHTML, ...fromScripts]));
    };

    // Immediate pass
    let found = scanOnce();
    if (found.length) return found;

    // Short wait loop for late content (up to ~2s total)
    const end = Date.now() + 2000;
    while (Date.now() < end) {
      await new Promise(r => setTimeout(r, 200));
      found = scanOnce();
      if (found.length) return found;
    }

    return [];
  } catch (e) {
    // Return a sentinel array with an error marker so the caller can show it
    return [{ __error: (e && e.message) || String(e) }];
  }
}

translateButton.addEventListener('click', async () => {
  resultsDiv.textContent = 'Scanning page...';

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      resultsDiv.textContent = 'No active tab found.';
      return;
    }

    // Inject scan function into ALL frames and collect results
    const execResults = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: scanForBscTags,
    });

    // Merge results from all frames
    const tagsSet = new Set();
    let errorMsg = null;

    for (const r of execResults) {
      const val = r && r.result;
      if (Array.isArray(val)) {
        // Error sentinel?
        if (val.length === 1 && val[0] && typeof val[0] === 'object' && '__error' in val[0]) {
          errorMsg = val[0].__error;
          continue;
        }
        val.forEach(t => tagsSet.add(t));
      }
    }

    if (errorMsg) {
      resultsDiv.textContent = `Scan error: ${errorMsg}`;
      return;
    }

    const tags = Array.from(tagsSet);

    if (!tags.length) {
      resultsDiv.textContent = 'No BSC tags found on this page.';
      return;
    }

    // Translate with your DB loaded via <script src="database.js"> in popup.html
    let out = '';
    tags.forEach(tag => {
      const label = (typeof bscDatabase !== 'undefined' && bscDatabase[tag]) || 'Unknown Tag';
      out += `<b>${safeHTML(tag)}</b>: ${safeHTML(label)}\n`;
    });

    resultsDiv.innerHTML = out;
  } catch (e) {
    resultsDiv.textContent = `Injection failed: ${(e && e.message) || String(e)}`;
  }
});
